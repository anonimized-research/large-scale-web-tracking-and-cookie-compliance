// jshint esversion: 8

const collector_io = require("./io");
const output_lib = require("./output");
const collector_connection = require("./connection");
const collector_inspect = require("./inspector");

const browsersession = require("./browser-session");
const { isFirstParty, getLocalStorage } = require("../lib/tools");

async function collector(args, logger) {
  // create the root folder structure
  collector_io.init(args);

  // create the output hash...
  const output = await output_lib.createOutput(args);

  const c = {
    browserSession: null,
    pageSession: null,
    logger: logger,

    args: args,
    output: output,
    source: null,
  };

  c.createSession = async function () {
    c.browserSession = await browsersession.createBrowserSession(
      c.args,
      c.logger
    );

    c.output.browser.version = await c.browserSession.browser.version();
    c.output.browser.user_agent = await c.browserSession.browser.userAgent();
    c.pageSession = await c.browserSession.start(c.output);
  };

  c.testConnection = async function () {
    await collector_connection.testHttps(c.output.uri_ins, c.output);
    await collector_connection.testSSL(
      c.output.uri_ins,
      c.args,
      c.logger,
      c.output
    );
  };

  c.acceptCookies = async function () {
    const acceptKeywords = [
    'accept all', 'agree all', 'continue', 'allow all', 'i consent',
    'understood', 'принять', 'согласен', 'aceptar todo', 'entendido', 
    'accepter', 'consentir', 'aceito', 'entendi', 'acepto', 'accept', 'agree', 'allow', 'aceptar','ok, got it'];

    // Combine all keywords into a single XPath expression
    const combinedXpath = acceptKeywords.map(keyword => {
      return `//*[not(self::style) and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '${keyword.toLowerCase()}') or contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), ' ${keyword.toLowerCase()} ') or contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), ' ${keyword.toLowerCase()}')]`;
    }).join(' | ');

    try {
      // Evaluate the combined XPath expression in the page context
      await c.pageSession.page.waitForTimeout(1000);
      const clicked = await c.pageSession.page.evaluate(async (xpath, acceptKeywords) => {
        const nodesSnapshot = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        let found = false;

        let node_candidate = undefined;
        let node_priority = Number.MAX_SAFE_INTEGER

        for (let i = 0; i < nodesSnapshot.snapshotLength; i++) {
          const node = nodesSnapshot.snapshotItem(i);

          const isClickable = (element) => {
            // Check for common attributes or properties that suggest clickability
            const style = window.getComputedStyle(element);
            return (
              element.hasAttribute('onclick') ||
              element.hasAttribute('role') && ['button', 'link'].includes(element.getAttribute('role')) ||
              element.tagName.toLowerCase() === 'a' ||
              ['pointer'].includes(style.cursor)
            );
          };

          if (node && isClickable(node) && node.innerHTML.trim().length < 30 && !node.innerHTML.toLowerCase().includes("agreement")) {
            counter = 0
            for(let keyword of acceptKeywords){
              if(node.innerHTML.toLowerCase().includes(keyword)){
                found = true;
                if(counter < node_priority){
                  node_candidate = node;
                  node_priority = counter;
                  console.log(node_candidate.innerHTML.trim(), node_priority)
                }
                break;
              }
              counter += 1;
            }
          }
        }
        if(found){
          console.log("Clicking:", node_candidate.innerHTML.trim(), node_priority)
          await node_candidate.click();
          return {found: found, text: node_candidate.innerHTML.trim()};
        }
        return found;
      }, combinedXpath, acceptKeywords);

      if (clicked && clicked.found) {
        await c.pageSession.page.waitForNavigation({ waitUntil: 'networkidle0', timeout: 5000 }).catch(() => {
          // Handle the timeout if no navigation occurs within the given time
        });
        c.output.accepted_cookies = clicked.found;
        c.output.accepted_cookies_text = clicked.text;
        return true
      }
      else{
        return false
      }
    } catch (error) {
      return false
    }
  }

  c.getPage = async function (url = null) {
    if (!url) {
      url = c.output.uri_ins;
    }

    const response = await c.pageSession.gotoPage(url);

    // log redirects
    c.output.uri_redirects = response
      .request()
      .redirectChain()
      .map((req) => {
        return req.url();
      });

    // log the destination uri after redirections
    c.output.uri_dest = c.pageSession.page.url();
    c.source = await c.pageSession.page.content();

    await c.pageSession.page.waitForTimeout(args.sleep); // in ms

    // record screenshots
    if (c.args.output && c.args.screenshots) {
      await c.pageSession.screenshot();
    }

    return response;
  };

  c.collectLinks = async function () {
    // get all links from page
    const links = await collector_inspect.collectLinks(c.pageSession.page, c.logger);

    var mappedLinks = await collector_inspect.mapLinksToParties(
      links,
      c.pageSession.hosts,
      c.pageSession.refs_regexp
    );

    c.output.links.firstParty = mappedLinks.firstParty;
    c.output.links.thirdParty = mappedLinks.thirdParty;

    c.output.links.social = await collector_inspect.filterSocialPlatforms(
      links
    );

    // prepare regexp to match links by their href or their caption
    c.output.links.keywords = await collector_inspect.filterKeywords(links);
  };

  c.collectCookies = async function () {
    c.output.cookies = await collector_inspect.collectCookies(
      c.pageSession.page,
      c.output.start_time
    );
  };

  c.collectForms = async function () {
    // unsafe webforms
    c.output.unsafeForms = await collector_inspect.unsafeWebforms(
      c.pageSession.page
    );
  };

  c.collectLocalStorage = async function () {
    c.output.localStorage = await getLocalStorage(c.pageSession.page, c.logger);
  };

  c.collectWebsocketLog = async function () {
    c.output.websocketLog = c.pageSession.webSocketLog;
  };

  c.browseSamples = async function (localStorage, user_set = []) {
    c.output.browsing_history = await c.pageSession.browseSamples(
      c.pageSession.page,
      localStorage,
      c.output.uri_dest,
      c.output.links.firstParty,
      user_set
    );
  };

  c.endSession = async function () {
    if(c.browserSession){
      await c.browserSession.end();
      c.browserSession = null;
    }
  
    c.output.end_time = new Date();
  };

  c.endPageSession = function () {
    c.pageSession = null;
  };
  
  return c;
}

module.exports = collector;